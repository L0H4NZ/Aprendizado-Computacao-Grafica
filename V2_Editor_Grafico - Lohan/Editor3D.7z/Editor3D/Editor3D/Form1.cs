﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Editor3D
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<Geometria> geometrias = new List<Geometria>();

        private List<Transformada> transformadas = new List<Transformada>();

        private float realWidth = 1.0f;
        private float realHeight = 1.0f;
        private float centerX;
        private float centerY;
        private float tamPixel;
        private Graphics context;
        private float theta, phi, rho, d;
    
        private Transformada t3d = new Transformada();
        private Point3D current = new Point3D();

        private void initgr() {

            Size d = panel1.Size;
            tamPixel = Math.Max(realWidth / (d.Width - 1), realHeight / (d.Height - 1));
            centerX = d.Width / 2;
            centerY = d.Height / 2;
        
        }

        private int ix(float x) {
            return (int) Math.Round(x / tamPixel + centerX);
        }

        private int iy(float y) {
            return (int) Math.Round(centerY - y / tamPixel);
        }

        private void desenhaGeometrias() {
        
            foreach (Geometria geometria in geometrias) {
            
                desenhaGeometria(geometria);
            }
        }

        private void desenhaGeometria(Geometria geometria) {
        
            //context.setColor(geometria.getCor());
        
            foreach (Aresta aresta in geometria.getArestas()) {
            
                //aqui preciso de dois pontos após transformada de visualização
            
                Point3D p1 = new Point3D(CgUtils.mult(geometria.getPontos()[aresta.pInicial].getValor(), t3d.getDefinicao()));
                Point3D p2 = new Point3D(CgUtils.mult(geometria.getPontos()[aresta.pFinal].getValor(), t3d.getDefinicao()));
            
                panel1.CreateGraphics().DrawLine(
                        new Pen(Brushes.Aqua),
                        ix(-d*p1.getX()/p1.getZ()), 
                        iy(-d*p1.getY()/p1.getZ()), 
                        ix(-d*p2.getX()/p2.getZ()), 
                        iy(-d*p2.getY()/p2.getZ()));
            }
        }

        public List<Geometria> getGeometrias()
        {
            return geometrias;
        }

        public void setGeometrias(List<Geometria> geometrias)
        {
            this.geometrias = geometrias;
        }

        public List<Transformada> getTransformadas()
        {
            return transformadas;
        }

        public void setTransformadas(List<Transformada> transformadas)
        {
            this.transformadas = transformadas;
        }

        private Geometria getGeometriaById(String id) {

            foreach (Geometria g in geometrias) {

                if (id != null && id == g.getId()) {

                    return g;
                }
            }
            return null;
         }

        public void addGeometria(Geometria geometria)
        {
            Geometria g = getGeometriaById(geometria.getId());

            if (g != null)
            {
                geometrias[geometrias.IndexOf(g)] = geometria;
            }
            else
            {
                geometrias.Add(geometria);
            }
        }

        private void iniciaGeometrias()
        {

            Geometria geometria = new Geometria();
            geometria.setId("cubo1");
            geometria.setCor(Color.Green);

            geometria.getPontos().Add(new Point3D(1, 1, 1));
            geometria.getPontos().Add(new Point3D(1, 1, -1));
            geometria.getPontos().Add(new Point3D(-1, 1, -1));
            geometria.getPontos().Add(new Point3D(-1, 1, 1));

            geometria.getPontos().Add(new Point3D(1, -1, 1));
            geometria.getPontos().Add(new Point3D(1, -1, -1));
            geometria.getPontos().Add(new Point3D(-1, -1, -1));
            geometria.getPontos().Add(new Point3D(-1, -1, 1));

            geometria.getArestas().Add(new Aresta(0, 1));
            geometria.getArestas().Add(new Aresta(1, 2));
            geometria.getArestas().Add(new Aresta(2, 3));
            geometria.getArestas().Add(new Aresta(3, 0));

            geometria.getArestas().Add(new Aresta(4, 5));
            geometria.getArestas().Add(new Aresta(5, 6));
            geometria.getArestas().Add(new Aresta(6, 7));
            geometria.getArestas().Add(new Aresta(7, 4));

            geometria.getArestas().Add(new Aresta(0, 4));
            geometria.getArestas().Add(new Aresta(1, 5));
            geometria.getArestas().Add(new Aresta(2, 6));
            geometria.getArestas().Add(new Aresta(3, 7));

            this.addGeometria(geometria); // getGeometrias().Add(geometria);

        }

        Boolean iniciou = false;

        public void configTransformada(float theta, float phi, float rho, float d)
        {

            this.theta = theta;
            this.phi = phi;
            this.rho = rho;
            this.d = d;

            t3d.setDefinicao(Transformada.Tv3D(theta, phi, rho));

            CgUtils.show(t3d.getDefinicao());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Graphics g = panel1.CreateGraphics();
            //Pen p = new Pen(Brushes.Aqua);
            //g.DrawLine(p, 10, 10, 300, 300);

            if (!iniciou)
            {
                initgr();
                iniciaGeometrias();
                float theta = 15.0f;
                float phi = 15.0f;
                float rho = 100.0f;
                float d = 10.0f;

                configTransformada(theta, phi, rho, d);
                iniciou = true;
            }

            desenhaGeometrias();

        }
    }
}
